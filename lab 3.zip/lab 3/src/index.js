import ReactDOM  from "react-dom";
import React from "react";
import './index.css'
import Game from "./game";


ReactDOM.render(
    <Game/>,
    document.getElementById('root')
);

