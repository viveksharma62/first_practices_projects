import { useState } from "react";
import './game.css';

const SimpleFlashCard = [
  { Question: " Which type of JavaScript language is ", answer: "object based", known: false },
  { Question: "Which of the following keywords is used to define a variable in Javascript ?", answer: "var,const and let", known: false },
  { Question: "How can a datatype be declared to be a constant type?", answer: "const", known: false },
  { Question: "Inside which HTML element do we put the JavaScript?", answer: "script", known: false },
];

const Game = () => {
  const [Card, setCard] = useState(SimpleFlashCard);
  const [CurrentIndex, setCurrentIndex] = useState(0);
  const [showAnswer, setshowAnswer] = useState(false);

  const toggleAnswer = () => {
    setshowAnswer(!showAnswer);
  };

  const nextQues = () => {
    if (CurrentIndex < Card.length - 1) {
      setCurrentIndex(CurrentIndex + 1);
      setshowAnswer(false);
    }
  };

  const prevQues = () => {
    if (CurrentIndex > 0) {
      setCurrentIndex(CurrentIndex - 1);
      setshowAnswer(false);
    }
  };

  const shuffleQues = () => {
    const updatedCard = [...Card];
    for (var i = updatedCard.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [updatedCard[i], updatedCard[j]] = [updatedCard[j], updatedCard[i]];
    }
    setCard(updatedCard);
    setCurrentIndex(0);
  };

  const markAnswer = () => {
    const newCard = [...Card];
    newCard[CurrentIndex].known = !newCard[CurrentIndex].known;
    setCard(newCard);
  };

  return (
    <div className="game">
      Card {CurrentIndex + 1} of {Card.length}<br /><br />
      {showAnswer ? Card[CurrentIndex].answer : Card[CurrentIndex].Question}<br /><br />
      <button id="show" onClick={toggleAnswer}>show {showAnswer ? "Question" : "answer"}</button>&nbsp;&nbsp;

      <button id="mark" onClick={markAnswer}>{Card[CurrentIndex].known ? "mark as unknown" : "mark as known"}</button><br /><br />&nbsp;&nbsp;

      <button id="pre" onClick={prevQues} disabled={CurrentIndex == 0}></button>&nbsp;&nbsp;
      <button id="nxt" onClick={nextQues} disabled={CurrentIndex == Card.length - 1}></button>&nbsp;&nbsp;

      <button id="shufle" onClick={shuffleQues}>

      </button>
    </div>
  );
};

export default Game;
